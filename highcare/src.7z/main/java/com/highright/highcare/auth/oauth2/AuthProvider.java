package com.highright.highcare.auth.oauth2;

public enum AuthProvider {

    LOCAL, GOOGLE, KAKAO, NAVER
}
