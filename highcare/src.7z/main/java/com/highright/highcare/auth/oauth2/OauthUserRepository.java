package com.highright.highcare.auth.oauth2;

import com.highright.highcare.auth.oauth2.OauthUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OauthUserRepository extends JpaRepository<OauthUser, String> {
    Optional<OauthUser> findByEmail(String email);

}
