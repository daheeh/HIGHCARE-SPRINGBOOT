package com.highright.highcare.auth.oauth2;


import java.util.Map;

public interface AuthenticationService {

    Map<String, Object> login(String email, String password);

}
