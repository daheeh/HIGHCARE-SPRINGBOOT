package com.highright.highcare.auth.oauth2;

import lombok.Builder;
import lombok.Getter;

import java.util.Map;

@Getter
public class OauthAttributes {

    private Map<String, Object> attributes;
    private String nameAttributeKey;
    private String name;                 // 네임, 닉네임
    private String email;
    private String picture;

    public OauthAttributes(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    @Builder
    public OauthAttributes(Map<String, Object> attributes, String nameAttributeKey,
                           String name, String email, String picture) {
        this.attributes = attributes;
        this.nameAttributeKey = nameAttributeKey;
        this.name = name;
        this.email = email;
        this.picture = picture;
    }



    /**
    *OauthAttributes of() Oauth2User에서 반환하는 사용자 정보는 map이기 때문에 값 하나하나 변환해줌
    *@author hdhye
    *작성일 2023-08-26
    **/
    public static OauthAttributes of(String registrationId, String userNameAttributeName,
                                     Map<String, Object> attributes){
        return OauthAttributes.builder()
                .name((String)attributes.get("name"))
                .email((String)attributes.get("email"))
                .picture((String)attributes.get("picture"))
                .attributes(attributes)
                .nameAttributeKey(userNameAttributeName)
                .build();
    }

    /**
    *OauthAttributes toEntity()  OauthAttribute에서 엔티티 생성 시점 = 처음 가입시
     *                          OauthAttribute 클래스 생성이 끝났으면 같은 패키지에 ssesisonUser 클래스 생성
    *@author hdhye
    *작성일 2023-08-26
    **/
    public OauthUser toEntity(){
        return OauthUser.builder()
                .name(name)
                .email(email)
                .picture(picture)
                .role(Role.GUEST) // 기본 권한
                .build();
    }
}
