package com.highright.highcare.auth.oauth2;

import lombok.Data;

@Data
public class AuthenticationRequest {
    private String email;
    private String password;
}
