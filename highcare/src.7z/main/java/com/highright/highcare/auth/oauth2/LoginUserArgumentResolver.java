package com.highright.highcare.auth.oauth2;

import lombok.RequiredArgsConstructor;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpSession;

@RequiredArgsConstructor
@Component
public class LoginUserArgumentResolver implements HandlerMethodArgumentResolver {

    private final HttpSession httpSession;
    /**
    *LoginUserArgumentResolver 컨트롤러 메소드의 특정 파라미터를 지원하는지 판단한다.
     * isLoginAnnotation: 파라미터에 @LoginUser붙어있는지,
     * isUserClass: 파라미터 클래스 타입이 SessionUser인지
     * 체크 후 boolean값 반환
    *@author hdhye
    *작성일 2023-08-26
    **/
    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        boolean isLoginUserAnnotation = parameter.getParameterAnnotation(LoginUser.class) != null;
        boolean isUserClass = SessionUser.class.equals(parameter.getParameterType());

        return isLoginUserAnnotation && isUserClass;
    }

    /**
    *LoginUserArgumentResolver 파라미터에 전달할 객체 세션에서 가져오기
    *@author hdhye
    *작성일 2023-08-26
    **/
    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
                                  NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {

        return httpSession.getAttribute("oauthUser");
    }
}
