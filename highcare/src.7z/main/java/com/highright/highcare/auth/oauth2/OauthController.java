package com.highright.highcare.auth.oauth2;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/login")
@RequiredArgsConstructor
public class OauthController {

    private final AuthenticationMapper authenticationMapper;

    @PostMapping("/oauth2/code/google")
    public ResponseEntity<AuthenticationResponse> login(@RequestBody AuthenticationRequest request) {
        return ResponseEntity.ok(authenticationMapper.login(request));
    }



}
