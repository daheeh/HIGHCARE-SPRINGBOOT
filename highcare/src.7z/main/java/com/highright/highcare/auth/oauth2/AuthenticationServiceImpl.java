package com.highright.highcare.auth.oauth2;

import com.highright.highcare.exception.ApiRequestException;
import com.highright.highcare.jwt.TokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService{

    private final AuthenticationManager authenticationManager;
    private OauthUserRepository oauthUserRepository;
    private TokenProvider tokenProvider;

    @Override
    public Map<String, Object> login(String email, String password) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
            OauthUser user = oauthUserRepository.findByEmail(email)
                    .orElseThrow(() -> new ApiRequestException("Email not found", HttpStatus.NOT_FOUND));
            String userRole = user.getRole().name();
            String token = tokenProvider.createOauthToken(email, userRole);
            Map<String, Object> response = new HashMap<>();
            response.put("user", user);
            response.put("token", token);
            return response;
        } catch (AuthenticationException e) {
            throw new ApiRequestException("Incorrect password or email", HttpStatus.FORBIDDEN);
        }    }
}
