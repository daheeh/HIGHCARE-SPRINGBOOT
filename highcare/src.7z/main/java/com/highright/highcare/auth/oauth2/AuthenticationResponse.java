package com.highright.highcare.auth.oauth2;

import lombok.Data;

@Data
public class AuthenticationResponse {
    private UserResponse user;
    private String token;
    private AuthProvider server;
}
