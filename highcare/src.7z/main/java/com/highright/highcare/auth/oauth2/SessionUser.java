package com.highright.highcare.auth.oauth2;

import com.highright.highcare.auth.oauth2.OauthUser;

import java.io.Serializable;

/**
*SessionUser 세션은 인증된 사용자 정보만 필요
 *           (세션에 저장하기 위해서 직렬화해야하는데 그냥 OauthUser는 entity와 관계를 맺고있어서 따로 sessionUser를 생성한다.)
*@author hdhye
*작성일 2023-08-26
**/
public class SessionUser implements Serializable {

    private String name;
    private String email;
    private String picture;

    public SessionUser(OauthUser oauthUser) {
        this.name = oauthUser.getName();
        this.email = oauthUser.getEmail();
        this.picture = oauthUser.getPicture();
    }

}
