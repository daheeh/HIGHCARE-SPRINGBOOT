package com.highright.highcare.bulletin.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class BulletinCategoriesDTO {
    public int categoryCode;
    public String nameBoard;
}
