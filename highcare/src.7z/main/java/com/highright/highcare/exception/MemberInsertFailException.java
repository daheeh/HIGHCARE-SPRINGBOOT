package com.highright.highcare.exception;


public class MemberInsertFailException extends RuntimeException {
    public MemberInsertFailException(String message) {
        super(message);
    }
}
