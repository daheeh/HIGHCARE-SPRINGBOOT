package com.highright.highcare.exception;

public class TokenException extends RuntimeException {

    public TokenException(String msg) {
        super(msg);
    }
}
