package com.highright.highcare.mypage.Repository;

import com.highright.highcare.mypage.entity.MyProfileFile;
import org.springframework.data.jpa.mapping.JpaPersistentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MyProfileFileRepository extends JpaRepository<MyProfileFile, Integer> {




}
