package com.highright.highcare.mypage.dto;

public class AnnualDTO {

//    private
}
