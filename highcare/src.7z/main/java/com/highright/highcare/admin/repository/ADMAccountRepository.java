package com.highright.highcare.admin.repository;

import com.highright.highcare.admin.entity.ADMAccount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ADMAccountRepository extends JpaRepository<ADMAccount, String> {
    ADMAccount findByEmpNo(int empNo);
}
